import React from "react";

const GroupPage = () => {
  return <div>GroupPage</div>;
};

export default GroupPage;
