import React from "react";

const Lesson = () => {
  return <div>Lesson</div>;
};

export default Lesson;
