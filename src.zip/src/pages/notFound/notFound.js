import React from "react";

const NotFound = () => {
  return <div>notFound</div>;
};

export default NotFound;
