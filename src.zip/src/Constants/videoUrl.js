// constants/videoUrls.js
export const videoUrls = {
    1: "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    2: "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
    3: "https://samplelib.com/lib/preview/mp4/sample-15s.mp4",
  };
  